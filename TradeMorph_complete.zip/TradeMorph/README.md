# TradeMorph - JSONL Transformer

A web application that transforms JSONL files using a Murex-to-Stella mapping CSV.

## Quick Setup (New Machine)

### Prerequisites
- **Node.js** (v16 or higher) - Download from https://nodejs.org/

### Installation Steps

```bash
# 1. Extract the project (if from zip)
unzip TradeMorph.zip
cd TradeMorph

# 2. Install dependencies
npm install

# 3. Start the server
npm start
```

The application will be available at **http://localhost:3000**

### Verify Installation
```bash
# Test with sample files
curl -X POST http://localhost:3000/api/transform \
  -F "jsonlFile=@sample_input.jsonl" \
  -F "mappingFile=@sample_mapping.csv"
```

---

## Overview

TradeMorph allows you to:
1. Upload an input JSONL file containing trade data
2. Upload a mapping CSV file (Murex Ref → Stella Ref)
3. Process and transform the data
4. Download the transformed JSONL output

## Transformation Rules

1. **Only MUREX rows with mapping are modified**: A row is transformed only if:
   - `SourceSystem === "MUREX"`
   - `CrpAdditionalAttributes.Ref` exists
   - The Ref value is found in the mapping CSV

2. **For matched rows**:
   - `CrpAdditionalAttributes.Ref` → Replaced with `Ref_roll` from mapping
   - `SourceSystem` → Changed to `"STELLA"`
   - `ExternalId` → Set to numeric portion of `Ref_roll` (e.g., `STELLA_7312806364` → `7312806364`)

3. **Unchanged rows**:
   - Non-MUREX rows (RAZOR, BLOOMBERG, etc.)
   - MUREX rows without a mapping entry
   - Rows missing `CrpAdditionalAttributes` or `Ref`

## Installation

```bash
# Navigate to project directory
cd TradeMorph

# Install dependencies
npm install

# Start the server
npm start
```

The application will be available at http://localhost:3000

## Project Structure

```
TradeMorph/
├── server/
│   ├── index.js          # Express server & API endpoints
│   └── transformer.js    # Core transformation logic
├── public/
│   ├── index.html        # Frontend HTML
│   ├── styles.css        # Styles
│   └── script.js         # Frontend JavaScript
├── uploads/              # Temporary upload storage (auto-created)
├── outputs/              # Transformed file storage (auto-created)
├── package.json
├── sample_input.jsonl    # Sample JSONL input
├── sample_mapping.csv    # Sample mapping CSV
├── sample_expected_output.jsonl  # Expected output
└── README.md
```

## API Endpoints

### POST /api/transform
Upload and transform files.

**Request**: `multipart/form-data`
- `jsonlFile`: Input JSONL file
- `mappingFile`: Mapping CSV file

**Response**:
```json
{
  "success": true,
  "downloadUrl": "/api/download/transformed_xxx.jsonl",
  "filename": "transformed_output.jsonl",
  "stats": {
    "totalRows": 13,
    "modifiedRows": 6,
    "unchangedRows": 7,
    "murexWithoutMapping": 3,
    "nonMurexRows": 2,
    "invalidJsonRows": 0,
    "mappingEntries": 6,
    "processingTimeMs": 15
  }
}
```

### GET /api/download/:filename
Download the transformed JSONL file.

## Sample Files

### Input JSONL (sample_input.jsonl)
```json
{"CrpAdditionalAttributes":{"Ref":"MXG_30324854"},"ExternalId":"30324854","SourceSystem":"MUREX"}
{"CrpAdditionalAttributes":{"Ref":"MXRFX_C_472482712"},"ExternalId":"472482712","SourceSystem":"RAZOR"}
{"CrpAdditionalAttributes":{"Ref":"MXG_99999999"},"ExternalId":"99999999","SourceSystem":"MUREX"}
```

### Mapping CSV (sample_mapping.csv)
```csv
Ref_base,Ref_roll
MXG_27244448,STELLA_7312518087
MXG_30324854,STELLA_7312806364
```

### Output JSONL
```json
{"CrpAdditionalAttributes":{"Ref":"STELLA_7312806364"},"ExternalId":"7312806364","SourceSystem":"STELLA"}
{"CrpAdditionalAttributes":{"Ref":"MXRFX_C_472482712"},"ExternalId":"472482712","SourceSystem":"RAZOR"}
{"CrpAdditionalAttributes":{"Ref":"MXG_99999999"},"ExternalId":"99999999","SourceSystem":"MUREX"}
```

## Key Features

- **Stream Processing**: Handles large files efficiently using line-by-line streaming
- **Validation**: Validates files and provides detailed error reporting
- **Statistics**: Shows comprehensive processing summary
- **Error Handling**: Gracefully handles malformed JSON rows
- **Drag & Drop**: Intuitive file upload interface
- **UTF-8 Support**: Preserves encoding throughout

## Tech Stack

- **Backend**: Node.js + Express
- **File Upload**: Multer
- **CSV Parsing**: csv-parse
- **Frontend**: Vanilla HTML/CSS/JavaScript (no framework dependencies)

## Configuration

Environment variables:
- `PORT`: Server port (default: 3000)

## License

ISC
