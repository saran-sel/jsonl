/**
 * TradeMorph Frontend Script
 * Handles file uploads, form submission, and results display
 */

document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const form = document.getElementById('transformForm');
    const jsonlInput = document.getElementById('jsonlFile');
    const mappingInput = document.getElementById('mappingFile');
    const jsonlDropZone = document.getElementById('jsonlDropZone');
    const mappingDropZone = document.getElementById('mappingDropZone');
    const jsonlFileName = document.getElementById('jsonlFileName');
    const mappingFileName = document.getElementById('mappingFileName');
    const submitBtn = document.getElementById('submitBtn');
    const resultsSection = document.getElementById('results');
    const downloadBtn = document.getElementById('downloadBtn');
    const errorMessage = document.getElementById('errorMessage');

    // State
    let downloadUrl = null;
    let downloadFilename = null;

    /**
     * Update file selection display
     */
    function updateFileDisplay(input, dropZone, fileNameEl) {
        if (input.files && input.files.length > 0) {
            const file = input.files[0];
            fileNameEl.textContent = file.name;
            dropZone.classList.add('has-file');
        } else {
            fileNameEl.textContent = 'No file selected';
            dropZone.classList.remove('has-file');
        }
        updateSubmitButton();
    }

    /**
     * Update submit button state
     */
    function updateSubmitButton() {
        const hasJsonl = jsonlInput.files && jsonlInput.files.length > 0;
        const hasMapping = mappingInput.files && mappingInput.files.length > 0;
        submitBtn.disabled = !(hasJsonl && hasMapping);
    }

    /**
     * Setup drag and drop for a drop zone
     */
    function setupDropZone(dropZone, input, fileNameEl) {
        ['dragenter', 'dragover'].forEach(event => {
            dropZone.addEventListener(event, (e) => {
                e.preventDefault();
                e.stopPropagation();
                dropZone.classList.add('drag-over');
            });
        });

        ['dragleave', 'drop'].forEach(event => {
            dropZone.addEventListener(event, (e) => {
                e.preventDefault();
                e.stopPropagation();
                dropZone.classList.remove('drag-over');
            });
        });

        dropZone.addEventListener('drop', (e) => {
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                input.files = files;
                updateFileDisplay(input, dropZone, fileNameEl);
            }
        });

        input.addEventListener('change', () => {
            updateFileDisplay(input, dropZone, fileNameEl);
        });
    }

    /**
     * Show error message
     */
    function showError(message) {
        errorMessage.textContent = message;
        errorMessage.classList.remove('hidden');
        resultsSection.classList.add('hidden');
    }

    /**
     * Hide error message
     */
    function hideError() {
        errorMessage.classList.add('hidden');
    }

    /**
     * Display results
     */
    function displayResults(data) {
        const stats = data.stats;

        // Update stat values
        document.getElementById('statTotal').textContent = stats.totalRows.toLocaleString();
        document.getElementById('statModified').textContent = stats.modifiedRows.toLocaleString();
        document.getElementById('statUnchanged').textContent = stats.unchangedRows.toLocaleString();
        document.getElementById('statNonMurex').textContent = stats.nonMurexRows.toLocaleString();
        document.getElementById('statNoMapping').textContent = stats.murexWithoutMapping.toLocaleString();
        document.getElementById('statInvalid').textContent = stats.invalidJsonRows.toLocaleString();

        // Processing info
        document.getElementById('mappingCount').textContent = stats.mappingEntries.toLocaleString();
        document.getElementById('processingTime').textContent = stats.processingTimeMs.toLocaleString();

        // Show errors if any
        const errorList = document.getElementById('errorList');
        const errorItems = document.getElementById('errorItems');
        
        if (data.errors && data.errors.length > 0) {
            errorItems.innerHTML = data.errors
                .map(err => `<li>Line ${err.line}: ${err.error}</li>`)
                .join('');
            errorList.classList.remove('hidden');
        } else {
            errorList.classList.add('hidden');
        }

        // Store download URL and filename
        downloadUrl = data.downloadUrl;
        downloadFilename = data.filename;
        
        // Update download button text with filename
        downloadBtn.innerHTML = `
            <svg class="download-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                <polyline points="7 10 12 15 17 10"></polyline>
                <line x1="12" y1="15" x2="12" y2="3"></line>
            </svg>
            Download ${downloadFilename}
        `;

        // Show results section
        resultsSection.classList.remove('hidden');
        
        // Scroll to results
        resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    /**
     * Handle form submission
     */
    async function handleSubmit(e) {
        e.preventDefault();
        hideError();
        resultsSection.classList.add('hidden');

        // Validate files
        if (!jsonlInput.files[0] || !mappingInput.files[0]) {
            showError('Please select both files.');
            return;
        }

        // Prepare form data
        const formData = new FormData();
        formData.append('jsonlFile', jsonlInput.files[0]);
        formData.append('mappingFile', mappingInput.files[0]);

        // Show loading state
        submitBtn.classList.add('loading');
        submitBtn.disabled = true;

        try {
            const response = await fetch('/api/transform', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (!response.ok || !data.success) {
                throw new Error(data.error || 'Transformation failed');
            }

            displayResults(data);

        } catch (error) {
            console.error('Error:', error);
            showError(error.message || 'An error occurred during transformation.');
        } finally {
            // Reset loading state
            submitBtn.classList.remove('loading');
            updateSubmitButton();
        }
    }

    /**
     * Handle download button click
     */
    function handleDownload() {
        if (downloadUrl) {
            window.location.href = downloadUrl;
        }
    }

    // Setup event listeners
    setupDropZone(jsonlDropZone, jsonlInput, jsonlFileName);
    setupDropZone(mappingDropZone, mappingInput, mappingFileName);
    form.addEventListener('submit', handleSubmit);
    downloadBtn.addEventListener('click', handleDownload);

    // Initial button state
    updateSubmitButton();
});
