/**
 * TradeMorph Server
 * Express server for JSONL transformation with Murex-to-Stella mapping
 */

const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const { transform } = require('./transformer');

// Cleanup interval in milliseconds (1 hour)
const CLEANUP_INTERVAL_MS = 60 * 60 * 1000;
// Max age for output files before cleanup (1 hour)
const MAX_FILE_AGE_MS = 60 * 60 * 1000;

const app = express();
const PORT = process.env.PORT || 3000;

// Ensure directories exist
const uploadsDir = path.join(__dirname, '..', 'uploads');
const outputsDir = path.join(__dirname, '..', 'outputs');

if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
}
if (!fs.existsSync(outputsDir)) {
    fs.mkdirSync(outputsDir, { recursive: true });
}

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadsDir);
    },
    filename: (req, file, cb) => {
        // Generate unique filename to avoid collisions
        const uniqueId = uuidv4();
        const ext = path.extname(file.originalname);
        cb(null, `${uniqueId}${ext}`);
    }
});

const upload = multer({
    storage: storage,
    limits: {
        fileSize: 2 * 1024 * 1024 * 1024, // 2GB limit for large files
    },
    fileFilter: (req, file, cb) => {
        // Accept JSONL, CSV, TSV and text files
        const allowedMimes = [
            'application/json',
            'text/plain',
            'text/csv',
            'text/tab-separated-values',
            'application/vnd.ms-excel'
        ];
        const allowedExts = ['.jsonl', '.json', '.csv', '.tsv', '.txt'];
        const ext = path.extname(file.originalname).toLowerCase();
        
        if (allowedExts.includes(ext)) {
            cb(null, true);
        } else {
            cb(new Error(`Invalid file type: ${ext}. Allowed: .jsonl, .csv`));
        }
    }
});

// Serve static files from public directory
app.use(express.static(path.join(__dirname, '..', 'public')));

// Parse JSON bodies
app.use(express.json());

/**
 * Health check endpoint
 */
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

/**
 * Main transformation endpoint
 * Accepts: jsonlFile (JSONL input) and mappingFile (CSV mapping)
 */
app.post('/api/transform', 
    upload.fields([
        { name: 'jsonlFile', maxCount: 1 },
        { name: 'mappingFile', maxCount: 1 }
    ]),
    async (req, res) => {
        const startTime = Date.now();
        let jsonlPath = null;
        let csvPath = null;
        let outputPath = null;

        try {
            // Validate files were uploaded
            if (!req.files || !req.files.jsonlFile || !req.files.mappingFile) {
                return res.status(400).json({
                    success: false,
                    error: 'Both JSONL file and mapping CSV file are required'
                });
            }

            jsonlPath = req.files.jsonlFile[0].path;
            csvPath = req.files.mappingFile[0].path;

            // Get original input filename and create output filename
            const originalName = req.files.jsonlFile[0].originalname;
            // Remove extension (.jsonl, .json, .txt) and add _transformed.jsonl.gz
            const baseName = originalName.replace(/\.(jsonl|json|txt)$/i, '');
            const outputId = uuidv4();
            const outputFilename = `${baseName}_transformed_${outputId}.jsonl.gz`;
            const downloadName = `${baseName}_transformed.jsonl.gz`;
            outputPath = path.join(outputsDir, outputFilename);

            console.log(`Processing transformation:`);
            console.log(`  Input JSONL: ${originalName}`);
            console.log(`  Mapping CSV: ${csvPath}`);
            console.log(`  Output: ${outputFilename}`);

            // Perform transformation
            const stats = await transform(jsonlPath, csvPath, outputPath);

            const processingTime = Date.now() - startTime;

            console.log(`Transformation complete in ${processingTime}ms`);
            console.log(`  Total rows: ${stats.totalRows}`);
            console.log(`  Modified: ${stats.modifiedRows}`);
            console.log(`  Unchanged: ${stats.unchangedRows}`);

            // Return success response with download URL
            res.json({
                success: true,
                downloadUrl: `/api/download/${encodeURIComponent(outputFilename)}`,
                filename: downloadName,
                stats: {
                    totalRows: stats.totalRows,
                    modifiedRows: stats.modifiedRows,
                    unchangedRows: stats.unchangedRows,
                    murexWithoutMapping: stats.murexWithoutMapping,
                    nonMurexRows: stats.nonMurexRows,
                    invalidJsonRows: stats.invalidJsonRows,
                    mappingEntries: stats.mappingEntries,
                    processingTimeMs: processingTime
                },
                errors: stats.errors.length > 0 ? stats.errors.slice(0, 10) : [] // Limit errors shown
            });

        } catch (error) {
            console.error('Transformation error:', error);
            res.status(500).json({
                success: false,
                error: error.message || 'An error occurred during transformation'
            });
        } finally {
            // Clean up uploaded files (keep output for download)
            if (jsonlPath && fs.existsSync(jsonlPath)) {
                fs.unlink(jsonlPath, (err) => {
                    if (err) console.error('Error deleting JSONL file:', err);
                });
            }
            if (csvPath && fs.existsSync(csvPath)) {
                fs.unlink(csvPath, (err) => {
                    if (err) console.error('Error deleting CSV file:', err);
                });
            }
        }
    }
);

/**
 * Download endpoint for transformed files (gzip compressed)
 */
app.get('/api/download/:filename', (req, res) => {
    const filename = decodeURIComponent(req.params.filename);
    
    // Sanitize filename to prevent directory traversal
    if (filename.includes('..') || filename.includes('/')) {
        return res.status(400).json({ error: 'Invalid filename' });
    }

    const filePath = path.join(outputsDir, filename);

    if (!fs.existsSync(filePath)) {
        return res.status(404).json({ error: 'File not found' });
    }

    // Extract the download name (remove UUID portion)
    // Format: baseName_transformed_uuid.jsonl.gz -> baseName_transformed.jsonl.gz
    const downloadName = filename.replace(/_[0-9a-f-]{36}\.jsonl\.gz$/i, '.jsonl.gz');

    // Set headers for gzip download
    res.setHeader('Content-Type', 'application/gzip');
    res.setHeader('Content-Encoding', 'identity'); // Don't let browser auto-decompress
    res.setHeader('Content-Disposition', `attachment; filename="${downloadName}"`);

    // Stream the file
    const fileStream = fs.createReadStream(filePath);
    fileStream.pipe(res);

    fileStream.on('end', () => {
        // Clean up output file after download
        setTimeout(() => {
            fs.unlink(filePath, (err) => {
                if (err) console.error('Error deleting output file:', err);
            });
        }, 5000); // Wait 5 seconds before cleanup
    });

    fileStream.on('error', (err) => {
        console.error('Error streaming file:', err);
        res.status(500).json({ error: 'Error downloading file' });
    });
});

/**
 * Error handling middleware
 */
app.use((error, req, res, next) => {
    if (error instanceof multer.MulterError) {
        if (error.code === 'LIMIT_FILE_SIZE') {
            return res.status(400).json({
                success: false,
                error: 'File size too large. Maximum size is 2GB.'
            });
        }
        return res.status(400).json({
            success: false,
            error: `Upload error: ${error.message}`
        });
    }
    
    console.error('Server error:', error);
    res.status(500).json({
        success: false,
        error: error.message || 'Internal server error'
    });
});

/**
 * Cleanup orphaned files older than MAX_FILE_AGE_MS
 */
function cleanupOrphanedFiles() {
    const now = Date.now();
    
    // Cleanup uploads directory
    cleanupDirectory(uploadsDir, now);
    
    // Cleanup outputs directory
    cleanupDirectory(outputsDir, now);
}

function cleanupDirectory(dirPath, now) {
    fs.readdir(dirPath, (err, files) => {
        if (err) {
            console.error(`Error reading directory ${dirPath}:`, err);
            return;
        }

        files.forEach(file => {
            const filePath = path.join(dirPath, file);
            fs.stat(filePath, (statErr, stats) => {
                if (statErr) {
                    console.error(`Error getting stats for ${filePath}:`, statErr);
                    return;
                }

                const fileAge = now - stats.mtimeMs;
                if (fileAge > MAX_FILE_AGE_MS) {
                    fs.unlink(filePath, (unlinkErr) => {
                        if (unlinkErr) {
                            console.error(`Error deleting old file ${filePath}:`, unlinkErr);
                        } else {
                            console.log(`Cleaned up orphaned file: ${file} (age: ${Math.round(fileAge / 60000)} minutes)`);
                        }
                    });
                }
            });
        });
    });
}

// Start cleanup job
setInterval(cleanupOrphanedFiles, CLEANUP_INTERVAL_MS);
// Run cleanup on startup
cleanupOrphanedFiles();

// Start server
app.listen(PORT, () => {
    console.log(`\n🚀 TradeMorph Server running at http://localhost:${PORT}`);
    console.log(`\n📁 Upload directory: ${uploadsDir}`);
    console.log(`📁 Output directory: ${outputsDir}`);
    console.log(`\nReady to transform JSONL files!\n`);
});

module.exports = app;
