/**
 * Transformer Module
 * Handles the transformation of JSONL data using Murex-to-Stella mapping
 */

const fs = require('fs');
const readline = require('readline');
const zlib = require('zlib');
const { parse } = require('csv-parse');

/**
 * Remove BOM and clean file content
 * @param {string} content - File content
 * @returns {string} - Cleaned content
 */
function removeBOM(content) {
    // Remove UTF-8 BOM
    if (content.charCodeAt(0) === 0xFEFF) {
        return content.slice(1);
    }
    // Remove UTF-8 BOM bytes
    if (content.startsWith('\uFEFF')) {
        return content.slice(1);
    }
    // Remove common BOM sequences
    return content.replace(/^\xEF\xBB\xBF/, '');
}

/**
 * Parse the mapping CSV/TSV file and return a Map of Ref_base -> Ref_roll
 * Handles: CSV, TSV, BOM, various column name formats
 * @param {string} csvFilePath - Path to the mapping CSV file
 * @returns {Promise<Map<string, string>>} - Mapping from Murex Ref to Stella Ref
 */
async function parseMappingCSV(csvFilePath) {
    return new Promise((resolve, reject) => {
        // Read entire file to handle BOM and detect format
        fs.readFile(csvFilePath, 'utf-8', (err, rawContent) => {
            if (err) {
                reject(new Error(`Error reading mapping file: ${err.message}`));
                return;
            }

            // Clean BOM and trim
            const content = removeBOM(rawContent).trim();
            
            console.log('=== Mapping File Debug ===');
            console.log(`File size: ${rawContent.length} bytes`);
            console.log(`First 200 chars: ${JSON.stringify(content.substring(0, 200))}`);
            
            // Detect delimiter
            const firstLine = content.split(/\r?\n/)[0];
            let delimiter = ',';
            
            if (firstLine.includes('\t')) {
                delimiter = '\t';
                console.log('Detected delimiter: TAB');
            } else if (firstLine.includes(',')) {
                delimiter = ',';
                console.log('Detected delimiter: COMMA');
            } else if (firstLine.includes(';')) {
                delimiter = ';';
                console.log('Detected delimiter: SEMICOLON');
            } else {
                console.log('Warning: No delimiter detected, defaulting to TAB');
                delimiter = '\t';
            }

            const mapping = new Map();
            
            const parser = parse(content, {
                columns: (header) => {
                    // Normalize column names: trim, remove BOM, handle case
                    const normalized = header.map(col => {
                        let clean = col.trim()
                            .replace(/^\uFEFF/, '')
                            .replace(/[\u200B-\u200D\uFEFF]/g, ''); // Remove zero-width chars
                        console.log(`Column found: "${col}" -> normalized: "${clean}"`);
                        return clean;
                    });
                    return normalized;
                },
                skip_empty_lines: true,
                trim: true,
                delimiter: delimiter,
                relax_column_count: true,
                relax_quotes: true,
                skip_records_with_error: true
            }, (parseErr, records) => {
                if (parseErr) {
                    console.error('Parse error:', parseErr);
                    reject(new Error(`CSV parsing error: ${parseErr.message}`));
                    return;
                }

                console.log(`Parsed ${records ? records.length : 0} records`);
                
                if (records && records.length > 0) {
                    console.log('First record keys:', Object.keys(records[0]));
                    console.log('First record:', JSON.stringify(records[0]));
                }

                // Process records with flexible column matching
                for (const row of (records || [])) {
                    const keys = Object.keys(row);
                    
                    // Find Ref_base column (case-insensitive, flexible matching)
                    const baseKey = keys.find(k => 
                        k.toLowerCase().includes('ref_base') || 
                        k.toLowerCase().includes('refbase') ||
                        k.toLowerCase() === 'ref_base'
                    );
                    
                    // Find Ref_roll column (case-insensitive, flexible matching)
                    const rollKey = keys.find(k => 
                        k.toLowerCase().includes('ref_roll') || 
                        k.toLowerCase().includes('refroll') ||
                        k.toLowerCase() === 'ref_roll'
                    );

                    if (baseKey && rollKey && row[baseKey] && row[rollKey]) {
                        const base = row[baseKey].toString().trim();
                        const roll = row[rollKey].toString().trim();
                        if (base && roll) {
                            mapping.set(base, roll);
                        }
                    }
                }

                console.log(`Loaded ${mapping.size} mapping entries`);
                if (mapping.size > 0) {
                    const first = mapping.entries().next().value;
                    console.log(`Sample mapping: ${first[0]} -> ${first[1]}`);
                }
                console.log('=== End Debug ===');
                
                resolve(mapping);
            });
        });
    });
}

/**
 * Extract numeric ID from Stella reference
 * Example: "STELLA_7312806364" -> "7312806364"
 * @param {string} stellaRef - The Stella reference string
 * @returns {string} - The numeric portion
 */
function extractStellaNumericId(stellaRef) {
    // Remove "STELLA_" prefix to get numeric ID
    if (stellaRef && stellaRef.startsWith('STELLA_')) {
        return stellaRef.substring(7); // "STELLA_" is 7 characters
    }
    // Fallback: extract any numeric portion
    const match = stellaRef.match(/(\d+)$/);
    return match ? match[1] : stellaRef;
}

/**
 * Transform a single JSON row based on mapping rules
 * @param {Object} row - Parsed JSON object
 * @param {Map<string, string>} mapping - Murex to Stella mapping
 * @param {Object} debug - Debug tracking object
 * @returns {{row: Object, modified: boolean, reason: string}} - Transformed row and status
 */
function transformRow(row, mapping, debug = null) {
    // Rule 1: Only process MUREX rows
    if (row.SourceSystem !== 'MUREX') {
        return { row, modified: false, reason: 'not-murex' };
    }

    // Rule 2: Check if CrpAdditionalAttributes exists
    if (!row.CrpAdditionalAttributes) {
        return { row, modified: false, reason: 'no-crp-attributes' };
    }

    // Rule 3: Check if Ref exists
    const currentRef = row.CrpAdditionalAttributes.Ref;
    if (!currentRef) {
        return { row, modified: false, reason: 'no-ref' };
    }

    // Rule 4: Check if mapping exists for this Ref
    const mappedRef = mapping.get(currentRef);
    if (!mappedRef) {
        // Track unmatched refs for debugging (only first 5)
        if (debug && debug.unmatchedRefs && debug.unmatchedRefs.length < 5) {
            debug.unmatchedRefs.push(currentRef);
        }
        return { row, modified: false, reason: 'no-mapping' };
    }

    // All conditions met - transform the row
    // Create a deep copy to avoid mutating original
    const transformedRow = JSON.parse(JSON.stringify(row));

    // Replace Ref with Stella reference
    transformedRow.CrpAdditionalAttributes.Ref = mappedRef;

    // Replace SourceSystem with "STELLA"
    transformedRow.SourceSystem = 'STELLA';

    // Replace ExternalId with numeric Stella ID (extracted from Ref_roll)
    transformedRow.ExternalId = extractStellaNumericId(mappedRef);

    return { row: transformedRow, modified: true, reason: 'transformed' };
}

/**
 * Process the JSONL file line by line using streams with backpressure handling
 * Optimized for very large files (millions of rows)
 * Output is gzip compressed
 * @param {string} inputPath - Path to input JSONL file
 * @param {string} outputPath - Path to output JSONL.gz file
 * @param {Map<string, string>} mapping - Murex to Stella mapping
 * @returns {Promise<Object>} - Processing statistics
 */
async function processJSONL(inputPath, outputPath, mapping) {
    return new Promise((resolve, reject) => {
        const stats = {
            totalRows: 0,
            modifiedRows: 0,
            unchangedRows: 0,
            murexWithoutMapping: 0,
            nonMurexRows: 0,
            invalidJsonRows: 0,
            errors: []
        };

        // Debug tracking for unmatched refs
        const debug = {
            unmatchedRefs: [],
            sampleMappingKeys: []
        };
        
        // Get sample mapping keys for comparison
        let keyCount = 0;
        for (const key of mapping.keys()) {
            if (keyCount < 5) {
                debug.sampleMappingKeys.push(key);
                keyCount++;
            } else {
                break;
            }
        }

        // Progress logging interval (every 100k rows)
        const PROGRESS_INTERVAL = 100000;
        let lastProgressLog = 0;
        const startTime = Date.now();

        // Create gzip compressed output stream with optimized settings for large files
        const gzip = zlib.createGzip({
            level: 6,  // Balanced compression level
            chunkSize: 64 * 1024  // 64KB chunks for better throughput
        });
        const fileStream = fs.createWriteStream(outputPath, {
            highWaterMark: 64 * 1024  // 64KB buffer
        });
        gzip.pipe(fileStream);
        
        // Create input stream with larger buffer for better read performance
        const inputStream = fs.createReadStream(inputPath, { 
            encoding: 'utf-8',
            highWaterMark: 64 * 1024  // 64KB buffer
        });
        
        const rl = readline.createInterface({
            input: inputStream,
            crlfDelay: Infinity
        });

        // Track if we need to pause for backpressure
        let isPaused = false;

        // Pre-compile regex for fast string matching (Option A optimization)
        const MUREX_PATTERN = /"SourceSystem"\s*:\s*"MUREX"/;

        const processLine = (line) => {
            stats.totalRows++;
            
            // Skip empty lines - just count, don't write
            if (!line.trim()) {
                return;
            }

            // OPTIMIZATION: Quick string pre-check before JSON parsing
            // If line doesn't contain MUREX as SourceSystem, write it unchanged
            // This avoids expensive JSON.parse/stringify for ~70% of rows
            if (!MUREX_PATTERN.test(line)) {
                // Not a MUREX row - write directly without parsing
                stats.unchangedRows++;
                stats.nonMurexRows++;
                const canContinue = gzip.write(line + '\n');
                if (!canContinue && !isPaused) {
                    isPaused = true;
                    rl.pause();
                }
                return;
            }

            // This is a MUREX row - need to parse and check mapping
            try {
                // Parse JSON
                const row = JSON.parse(line);
                
                // Transform the row, passing debug object to track issues
                const result = transformRow(row, mapping, debug);
                
                // Write transformed or original row - check backpressure
                const canContinue = gzip.write(JSON.stringify(result.row) + '\n');

                // Update statistics
                if (result.modified) {
                    stats.modifiedRows++;
                } else {
                    stats.unchangedRows++;
                    
                    // Track specific reasons
                    if (result.reason === 'not-murex') {
                        stats.nonMurexRows++;
                    } else if (result.reason === 'no-mapping') {
                        stats.murexWithoutMapping++;
                    }
                }

                // Handle backpressure - pause reading if buffer is full
                if (!canContinue && !isPaused) {
                    isPaused = true;
                    rl.pause();
                }
            } catch (parseError) {
                // Handle malformed JSON - write original line unchanged
                stats.invalidJsonRows++;
                gzip.write(line + '\n');
                // Only store first 100 errors to avoid memory issues
                if (stats.errors.length < 100) {
                    stats.errors.push({
                        line: stats.totalRows,
                        error: parseError.message
                    });
                }
            }

            // Log progress for large files
            if (stats.totalRows - lastProgressLog >= PROGRESS_INTERVAL) {
                lastProgressLog = stats.totalRows;
                const elapsed = (Date.now() - startTime) / 1000;
                const rate = Math.round(stats.totalRows / elapsed);
                console.log(`  Progress: ${(stats.totalRows / 1000000).toFixed(2)}M rows processed (${rate} rows/sec)`);
            }
        };

        rl.on('line', processLine);

        // Handle backpressure - resume when buffer drains
        gzip.on('drain', () => {
            if (isPaused) {
                isPaused = false;
                rl.resume();
            }
        });

        rl.on('close', () => {
            gzip.end();
        });

        rl.on('error', (err) => {
            gzip.end();
            reject(new Error(`Error reading JSONL file: ${err.message}`));
        });

        inputStream.on('error', (err) => {
            gzip.end();
            reject(new Error(`Error opening input file: ${err.message}`));
        });

        gzip.on('error', (err) => {
            reject(new Error(`Error compressing output: ${err.message}`));
        });

        fileStream.on('error', (err) => {
            reject(new Error(`Error writing output file: ${err.message}`));
        });

        fileStream.on('finish', () => {
            const elapsed = (Date.now() - startTime) / 1000;
            console.log(`  Completed: ${stats.totalRows.toLocaleString()} rows in ${elapsed.toFixed(1)}s`);
            
            // Debug output for troubleshooting matching issues
            if (stats.murexWithoutMapping > 0 && stats.modifiedRows === 0) {
                console.log('\n=== DEBUG: No matches found ===');
                console.log('Sample mapping keys (Ref_base):', debug.sampleMappingKeys);
                console.log('Sample unmatched Refs from JSONL:', debug.unmatchedRefs);
                console.log('Check if the Ref format matches between files!');
                console.log('================================\n');
            }
            
            resolve(stats);
        });
    });
}

/**
 * Main transformation function
 * @param {string} jsonlPath - Path to input JSONL file
 * @param {string} csvPath - Path to mapping CSV file
 * @param {string} outputPath - Path to output JSONL file
 * @returns {Promise<Object>} - Processing statistics
 */
async function transform(jsonlPath, csvPath, outputPath) {
    // Step 1: Parse the mapping CSV
    const mapping = await parseMappingCSV(csvPath);
    
    // Step 2: Process the JSONL file
    const stats = await processJSONL(jsonlPath, outputPath, mapping);
    
    // Add mapping info to stats
    stats.mappingEntries = mapping.size;
    
    return stats;
}

module.exports = {
    transform,
    parseMappingCSV,
    transformRow,
    extractStellaNumericId
};
