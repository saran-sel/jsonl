// PM2 Configuration for Production
module.exports = {
  apps: [{
    name: 'trademorph',
    script: 'server/index.js',
    instances: 1,  // Use 1 instance for file processing (avoid conflicts)
    exec_mode: 'fork',
    watch: false,
    max_memory_restart: '2G',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    // Logging
    log_file: './logs/combined.log',
    out_file: './logs/out.log',
    error_file: './logs/error.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    // Auto restart on crash
    autorestart: true,
    restart_delay: 1000,
    max_restarts: 10
  }]
};
