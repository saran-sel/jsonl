# TradeMorph Linux Deployment Guide

## Quick Deployment (Recommended)

### Step 1: Upload files to Linux server

Transfer the `TradeMorph_linux.tar.gz` file to your server:

```bash
# From your local machine:
scp TradeMorph_linux.tar.gz user@your-server:/home/user/
```

### Step 2: Extract and run

SSH into your server and run:

```bash
# Connect to server
ssh user@your-server

# Extract files
tar -xzf TradeMorph_linux.tar.gz
cd TradeMorph

# Run quick start (installs everything automatically)
bash deploy/quickstart.sh
```

### Step 3: Share with team

The script will display the URL (e.g., `http://192.168.1.100:3000`).
Share this URL with your team members who are on the same network/VPN.

---

## Manual Installation

If the quick start script doesn't work, follow these manual steps:

### Install Node.js 18.x

**Ubuntu/Debian:**
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
```

**CentOS/RHEL/Amazon Linux:**
```bash
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
sudo yum install -y nodejs
```

### Install PM2 (Process Manager)
```bash
sudo npm install -g pm2
```

### Setup Application
```bash
cd TradeMorph
npm install --production
mkdir -p uploads outputs logs
```

### Start Application
```bash
pm2 start ecosystem.config.js
pm2 save
pm2 startup  # Follow the instructions to enable auto-start on boot
```

---

## Managing the Application

| Command | Description |
|---------|-------------|
| `pm2 status` | Check if app is running |
| `pm2 logs trademorph` | View real-time logs |
| `pm2 restart trademorph` | Restart the app |
| `pm2 stop trademorph` | Stop the app |
| `pm2 delete trademorph` | Remove from PM2 |

---

## Firewall Configuration

If team members can't access the app, you may need to open port 3000:

**Ubuntu/Debian (UFW):**
```bash
sudo ufw allow 3000
```

**CentOS/RHEL (firewalld):**
```bash
sudo firewall-cmd --permanent --add-port=3000/tcp
sudo firewall-cmd --reload
```

**AWS Security Group:**
- Add inbound rule: TCP port 3000, Source: Your VPN/office IP range

---

## Changing the Port

Edit `ecosystem.config.js` and change the PORT:
```javascript
env: {
  NODE_ENV: 'production',
  PORT: 8080  // Change to your desired port
}
```

Then restart:
```bash
pm2 restart trademorph
```

---

## Performance Tips

1. **Use SSD storage** - Faster disk I/O for large files
2. **Allocate more RAM** - Node.js performs better with available memory
3. **Same network** - For fastest uploads, users should be on same network as server

---

## Troubleshooting

**App not accessible?**
1. Check if running: `pm2 status`
2. Check logs: `pm2 logs trademorph`
3. Verify port is open: `curl http://localhost:3000`
4. Check firewall settings

**Out of disk space?**
- Old files are auto-cleaned after 1 hour
- Manual cleanup: `rm -rf uploads/* outputs/*`

**Permission denied?**
```bash
chmod -R 755 /path/to/TradeMorph
chmod -R 777 /path/to/TradeMorph/uploads
chmod -R 777 /path/to/TradeMorph/outputs
```
