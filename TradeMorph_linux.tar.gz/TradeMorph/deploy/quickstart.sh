#!/bin/bash

# Quick Start Script - Run this after uploading files to Linux server
# Usage: bash quickstart.sh

set -e

echo "=========================================="
echo "  TradeMorph Quick Start"
echo "=========================================="

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed!"
    echo ""
    echo "Install Node.js 18.x with:"
    echo ""
    echo "Ubuntu/Debian:"
    echo "  curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -"
    echo "  sudo apt-get install -y nodejs"
    echo ""
    echo "CentOS/RHEL/Amazon Linux:"
    echo "  curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -"
    echo "  sudo yum install -y nodejs"
    exit 1
fi

echo "✓ Node.js $(node --version) found"

# Check npm
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed!"
    exit 1
fi

echo "✓ npm $(npm --version) found"

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Install dependencies
echo ""
echo ">>> Installing dependencies..."
npm ci --production 2>/dev/null || npm install --production

# Create directories
mkdir -p uploads outputs logs

# Install PM2 if not available
if ! command -v pm2 &> /dev/null; then
    echo ""
    echo ">>> Installing PM2 process manager..."
    sudo npm install -g pm2
fi

echo "✓ PM2 $(pm2 --version) found"

# Start with PM2
echo ""
echo ">>> Starting TradeMorph..."
pm2 delete trademorph 2>/dev/null || true
pm2 start ecosystem.config.js

# Setup startup
pm2 save

# Get IP address
IP=$(hostname -I | awk '{print $1}' 2>/dev/null || echo "your-server-ip")

echo ""
echo "=========================================="
echo "  ✓ TradeMorph is running!"
echo "=========================================="
echo ""
echo "Access the app at:"
echo "  http://$IP:3000"
echo ""
echo "Share this URL with your team!"
echo ""
echo "Commands:"
echo "  pm2 status          - Check status"
echo "  pm2 logs trademorph - View logs"
echo "  pm2 restart trademorph - Restart"
echo ""
