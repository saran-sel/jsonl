#!/bin/bash

# TradeMorph Linux Installation Script
# Run as: sudo bash install.sh

set -e

echo "=========================================="
echo "  TradeMorph Installation Script"
echo "=========================================="

# Detect OS
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$ID
else
    echo "Cannot detect OS. Please install manually."
    exit 1
fi

echo "Detected OS: $OS"

# Install Node.js 18.x LTS
install_nodejs() {
    echo ""
    echo ">>> Installing Node.js 18.x LTS..."
    
    if [ "$OS" = "ubuntu" ] || [ "$OS" = "debian" ]; then
        curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
        sudo apt-get install -y nodejs
    elif [ "$OS" = "centos" ] || [ "$OS" = "rhel" ] || [ "$OS" = "fedora" ] || [ "$OS" = "amzn" ]; then
        curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
        sudo yum install -y nodejs
    else
        echo "Unknown OS. Please install Node.js 18.x manually from https://nodejs.org/"
        exit 1
    fi
    
    echo "Node.js version: $(node --version)"
    echo "npm version: $(npm --version)"
}

# Install PM2 globally
install_pm2() {
    echo ""
    echo ">>> Installing PM2 process manager..."
    sudo npm install -g pm2
    echo "PM2 version: $(pm2 --version)"
}

# Create app directory
setup_app() {
    APP_DIR="/opt/trademorph"
    
    echo ""
    echo ">>> Setting up application in $APP_DIR..."
    
    # Create directory
    sudo mkdir -p $APP_DIR
    sudo mkdir -p $APP_DIR/logs
    sudo mkdir -p $APP_DIR/uploads
    
    # Copy files (assuming script is run from TradeMorph directory)
    SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
    PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
    
    sudo cp -r "$PROJECT_DIR/server" $APP_DIR/
    sudo cp -r "$PROJECT_DIR/public" $APP_DIR/
    sudo cp "$PROJECT_DIR/package.json" $APP_DIR/
    sudo cp "$PROJECT_DIR/package-lock.json" $APP_DIR/
    sudo cp "$PROJECT_DIR/ecosystem.config.js" $APP_DIR/
    
    # Install dependencies
    cd $APP_DIR
    sudo npm ci --production
    
    # Set permissions
    sudo chown -R $(whoami):$(whoami) $APP_DIR
    chmod -R 755 $APP_DIR
    chmod -R 777 $APP_DIR/uploads
    chmod -R 777 $APP_DIR/logs
}

# Setup PM2 to start on boot
setup_pm2_startup() {
    echo ""
    echo ">>> Configuring PM2 startup..."
    pm2 startup
    cd /opt/trademorph
    pm2 start ecosystem.config.js
    pm2 save
}

# Main installation
main() {
    # Check if running as root
    if [ "$EUID" -ne 0 ]; then 
        echo "Please run with sudo: sudo bash install.sh"
        exit 1
    fi
    
    # Check if Node.js is installed
    if command -v node &> /dev/null; then
        echo "Node.js is already installed: $(node --version)"
        read -p "Reinstall Node.js? (y/n): " REINSTALL
        if [ "$REINSTALL" = "y" ]; then
            install_nodejs
        fi
    else
        install_nodejs
    fi
    
    # Install PM2
    if command -v pm2 &> /dev/null; then
        echo "PM2 is already installed: $(pm2 --version)"
    else
        install_pm2
    fi
    
    # Setup application
    setup_app
    
    # Start application
    setup_pm2_startup
    
    # Get IP address
    IP=$(hostname -I | awk '{print $1}')
    
    echo ""
    echo "=========================================="
    echo "  Installation Complete!"
    echo "=========================================="
    echo ""
    echo "TradeMorph is now running at:"
    echo "  http://$IP:3000"
    echo ""
    echo "Useful PM2 commands:"
    echo "  pm2 status          - Check app status"
    echo "  pm2 logs trademorph - View logs"
    echo "  pm2 restart trademorph - Restart app"
    echo "  pm2 stop trademorph - Stop app"
    echo ""
    echo "App files location: /opt/trademorph"
    echo ""
}

main
